using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace nuevo.Views.Home
{
    public class InicioModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
